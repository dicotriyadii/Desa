<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\pendanaanModel;
 
class APICekPembayaran extends ResourceController
{
    use ResponseTrait;


    public function show($id = null)
    {
        $model = new pendanaanModel();
        $data = $model->getWhere(['nomorTelepon' => $id])->getResult();
        foreach ($data as $d) {
            if($d->status == 'Belum Validasi' && $d->nomorTelepon == $id){
                return $this->failNotFound('Data yang dimasukkan salah, silahkan coba lagi');
            }
        }
            return $this->respond($data,201);
    }

    // create a product
    public function create()
    {
        $model = new pendanaanModel();
        $data = [
            'nomorTelepon' => $this->request->getPost('nomorTelepon'),
            'password' => $this->request->getPost('password'), 
        ];
        $data = json_decode(file_get_contents("php://input"),TRUE);
        $database = $model->getWhere(['nomorTelepon' => $data['nomorTelepon']])->getResult();
        foreach ($database as $d) {
            if($d->status == 'Sudah Validasi'){
            return $this->respond($database,201);
        }else{
            return $this->failNotFound('Data yang dimasukkan salah, silahkan coba lagi');
        }
        }
    }
 
}