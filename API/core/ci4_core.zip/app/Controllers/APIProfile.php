<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\profileModel;
 
class APIProfile extends ResourceController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
        $model = new profileModel();
        $data = $model->findAll();
        return $this->respond($data, 200);
    }
 
}