<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\userModel;
 
class APILogin extends ResourceController
{
    use ResponseTrait;

    // create a product
    public function create()
    {
        $model = new userModel();
        $data = [
            'nomorTelepon' => $this->request->getPost('nomorTelepon'),
            'password' => $this->request->getPost('password'), 
        ];
        $data = json_decode(file_get_contents("php://input"),TRUE);
        $database = $model->getWhere(['nomorTelepon' => $data['nomorTelepon']])->getResult();
        $database2 = $model->getWhere(['password' => $data['password']])->getResult();

        if($database == TRUE && $database2 == TRUE){
            return $this->respond($database,201);
        }else{
            return $this->failNotFound('Data yang dimasukkan salah, silahkan coba lagi');
        }
    }
 
}