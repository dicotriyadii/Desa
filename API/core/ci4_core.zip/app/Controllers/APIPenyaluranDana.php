<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\pencairanModel;
 
class APIPenyaluranDana extends ResourceController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
        $model = new pencairanModel();
        $data = $model->findAll();
        foreach ($data as $d) {
            $jumlah[] = $d['jumlah'];
        }
        $jumlahBarang = array_sum($jumlah);
        $hasil = array($jumlahBarang);
        return $this->respond($hasil, 200);
    }
 
}