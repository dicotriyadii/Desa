<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\pendanaanModel;
 
class APIPendanaan extends ResourceController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
        $model = new pendanaanModel();
        $data = $model->findAll();
        return $this->respond($data, 200);
    }
 
    // // get single product
    public function show($id = null)
    {
        $model = new pendanaanModel();
        $data = $model->getWhere(['idPenerimaanDana' => $id])->getResult();
        if($data){
            return $this->respond($data);
        }else{
            return $this->failNotFound('No Data Found with id '.$id);
        }
    }
 
    // create a product
    public function create()
    {

        error_reporting(0);
        $ket='Pembelajaran bulan ke-1';
        $produk='COAS (Coding Asik dan Seru)';
        $total=350000;
               
        $url = 'https://my.ipaymu.com/payment.htm';  // URL Payment iPaymu           
        $params = array(   // Prepare Parameters            
            'key'      => '467B0839-0AA8-4A32-952C-B9543799432F', // API Key Merchant / Penjual
            'action'   => 'payment',
            'product'  => $produk,
            'price'    => $total, // Total Harga
            'quantity' => 1,
            'comments' => $ket, // Optional
            
        //'ureturn'  => 'http://delipay.mannaglobalcoid.com/inputorderan.php?kodetoko='.$kodetoko.'&produk='.$produk.'&total='.$total.
            '&jumlah='.$jumlah.'&nama='.$nama,  
            'unotify'  => 'https://coas.online',
            'ucancel'  => 'https://coas.online',
            'format'   => 'json' // Format: xml atau json. Default: xml
            );
         
        $params_string = http_build_query($params);
         
        //open connection
        $ch = curl_init();
         
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($params));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
         
        //execute post
        $request = curl_exec($ch);
        die($request)
        if($request === false ){
            echo 'Curl Error: ' . curl_error($ch);
        }else{
            $result = json_decode($request, true);
            return $this->respond($result, 200);
        }
    }
 
    // update product
    public function update($id = null)
    {
        $model = new pendanaanModel();
        $data1 = $model->getWhere(['status' => "Belum Validasi"])->getResult();
        $json = $this->request->getJSON();
        if($json){
            $data = [
                'status' => $json->status,
                'noTransaksi' =>$json->noTransaksi
            ];
        }else{
            $input = $this->request->getRawInput();
            $data = [
                'status' => $json->status,
                'noTransaksi' =>$json->noTransaksi
            ];
        }
        // die(print_r($data));
        // Insert to Database
        foreach ($data1 as $d) {
            $model->update($d->idPenerimaanDana, $data);            
        }
        $response = [
            'status'   => 201,
            'error'    => null,
            'messages' => [
                'success' => 'Data Updated'
            ]
        ];
        return $this->respond($response);
    }
 
    // // delete product
    // public function delete($id = null)
    // {
    //     $model = new ProductModel();
    //     $data = $model->find($id);
    //     if($data){
    //         $model->delete($id);
    //         $response = [
    //             'status'   => 200,
    //             'error'    => null,
    //             'messages' => [
    //                 'success' => 'Data Deleted'
    //             ]
    //         ];
             
    //         return $this->respondDeleted($response);
    //     }else{
    //         return $this->failNotFound('No Data Found with id '.$id);
    //     }
         
    // }
 
}