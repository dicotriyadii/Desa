<?php namespace App\Controllers;
 
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\pendanaanModel;
 
class APITerimaDana extends ResourceController
{
    use ResponseTrait;
    // get all product
    public function index()
    {
        $model = new pendanaanModel();
        $data = $model->findAll();
        // die(print_r($data[0]['jumlah']));
        // $jumlah = array_sum($data[0]['jumlah']);
        // die(print_r($jumlah));
        foreach ($data as $d) {
            $jumlah[] = $d['jumlah'];
        }
        $jumlahBarang = array_sum($jumlah);
        $hasil = array($jumlahBarang);
        return $this->respond($hasil, 200);
    }
 
}