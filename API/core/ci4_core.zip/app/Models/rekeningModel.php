<?php namespace App\Models;
 
use CodeIgniter\Model;

class rekeningModel extends Model
{
    protected $table = 'tblRekening';
    protected $primaryKey = 'idRekening';
    protected $allowedFields = ['namaRekening','nomorRekening','namaBank'];
}