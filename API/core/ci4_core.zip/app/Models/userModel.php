<?php namespace App\Models;
 
use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'tblUser';
    protected $primaryKey = 'idUser';
    protected $allowedFields = ['namaUser','nomorTelepon','password'];
}