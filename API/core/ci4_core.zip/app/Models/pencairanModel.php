<?php namespace App\Models;
 
use CodeIgniter\Model;

class pencairanModel extends Model
{
    protected $table = 'tblpencairandana';
    protected $primaryKey = 'idPencairanDana';
    protected $allowedFields = ['penerimaDana','tanggal','jumlah','keterangan'];
}